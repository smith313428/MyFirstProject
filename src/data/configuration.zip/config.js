export const email= {
  gmail: "smith313428@gmail.com / rcb198014 (chat.openai.com: gogool login) reafe198014@outlook.com",
  gmail: "smith313104@gmail.com / mith313104!qwe, smith313104@outlook.com",
  gmail: "shailesh.tech195@gmail.com   //   mith313428 , shailesh313104@outlook.com",
  gmail: "patrick.phong196@gmail.com   // mith313428, patrick313104@outlook.com",
  Outlook: "reafe198014@outlook.com / rcb198014    : (outlook, skype)",
  Outlook: "smith313104@outlook.com / mith313104",
  Outlook: "patrick313104@outlook.com / mith313104",
  Outlook: "shailesh313104@outlook.com / mith313104",
  Outlook: "tianxiang528@outlook.com  / Admin!234@#$was  (PPassword1234!@#$) smith313428@gmail.com",

  GitHub: "smith313428/mith313428, smith313428@gmail.com/mith313428",
  Bitbucket : "shailesh.tech195@gmail.com / mith313428   (shailesh195 // mith313428) // ATBBX57Yv6NzLKScdwK8RgHvkhab0C660AA3 : pass",
  Bybit : " smith313428@gmail.com/Rcb198014",
  binance : "tianxiang528@outlook.com  // AKIA6JAPJ7AGIYQNRVKK",
  binance : "smith313104@outlook.com  // Admin!234@rcb  : Ok",
  binance : "patrick313104@outlook.com  // Admin!234@rcb  : Ok",
  kuCoin : "smith313104@gmail.com  //Admin!234@rcb",
  Bitmex : "smith313104@gmail.com  ///Admin!234@qwe",
  metaa:"0x938E7bBd97C2d08F6DD5ecCb0197A1DC2aDDa208 : metamask account , mith313428 : pass",
  meta : "0xAD16af0b62Ddad8f515760E7c905481215bD96f1 :metamask account(new)",

  Jong : "live:ae105b8527b25a0f",

 
  gmail: "jacob.itdream@gmail.com/Frontend1! ",
  gmail: "steven.bestsolution@gmail.ocm / frontend",

  Linkedin: "smith313104@gmail.com / mith313104",
  Linkedin: "shailesh.tech195@gmail.com /  mith313428",

  Gitlab: "reafe12345 / rcb198014 , smith313428/rcb198014",
  GitHub : "reafe123 / rcb198014 , smith313428/mith313428, 12435-reafe/rcb198014 ",
  Bitbucket : "reafe198014outlook.com/rcb198014",
  Bitbucket : "smith313428@gmail.com / mith313428",
  Gitlab : " polarislee1984/ qwer12341!A (rotation, roomres)",

  binance : "smith313428@gmail.com  // Admin!234@qwe",

  Apple_ID : "Smith313104@gmail.com // Mith313104",
  Figma : " smith313428@gmaial.com // mith313428 ",

  Dl: {'live:cid.60467dfadabcf70f' : 'Green Card SSN Driver License Passport',
  'live:buddyjam0' : 'ID Card, Driving License, Green Card, Passport',
  'live:cbc6048e7705e1b' : 'Stripe,USBank& Documents,SSN,wise,revolut'},

  Astrill: 'dinuo9797@gmail.com // David20150812sanhaojie!!!  polarislee1984@outlook.com // ASf7695SF%DS(F',

  address : "126 Geylang East Ave 1, Singapore 381126",
  name:"Wei Jie Tan(	First Name: Wei Jie Last Name: Tan)",
  bb:"1983/3/16"
}